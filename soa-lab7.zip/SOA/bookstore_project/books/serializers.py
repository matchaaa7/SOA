from rest_framework import serializers
from decimal import Decimal
from .models import Book, Publisher

class PublisherSerializer(serializers.ModelSerializer):
    class Meta:
        model = Publisher
        fields = ['id', 'name', 'website'] 

class BookSerializer(serializers.ModelSerializer):
    discounted_price = serializers.SerializerMethodField()
    publisher = PublisherSerializer(read_only=True)
    publisher_id = serializers.PrimaryKeyRelatedField(
        queryset=Publisher.objects.all(),
        source='publisher',
        write_only=True
    )

    class Meta:
        model = Book
        fields = ['id', 'title', 'author', 'price', 'published_date', 'isbn', 'discounted_price', 'publisher', 'publisher_id']  

    def get_discounted_price(self, obj):
        return round(obj.price * Decimal('0.85'), 2)

    def validate(self, data):
        title = data.get('title', '').lower()
        if 'free' in title:
            data['price'] = Decimal('0.00')
        else:
            if data.get('price', 0) <= 0:
                raise serializers.ValidationError({"price": "ราคาต้องมากกว่า 0"})
        return data
