from django.contrib import admin
from .models import Book, Publisher

@admin.register(Publisher)
class PublisherAdmin(admin.ModelAdmin):
    list_display = ['id', 'name', 'website']
    search_fields = ['name']

@admin.register(Book)
class BookAdmin(admin.ModelAdmin):
    list_display = ['id', 'title', 'author', 'publisher', 'price', 'published_date']
    list_filter = ['publisher', 'published_date']
    search_fields = ['title', 'author', 'isbn']
    autocomplete_fields = ['publisher']
