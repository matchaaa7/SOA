from django.db import models

class Publisher(models.Model):
    name = models.CharField(max_length=255)
    website = models.URLField(blank=True)  # เว็บไซต์สำนักพิมพ์ (ไม่บังคับใส่)

    def __str__(self):
        return self.name

class Book(models.Model):
    title = models.CharField(max_length=255)
    author = models.CharField(max_length=255)
    published_date = models.DateField()
    isbn = models.CharField(max_length=13)
    price = models.DecimalField(max_digits=6, decimal_places=2)
    publisher = models.ForeignKey(Publisher,on_delete=models.CASCADE,related_name='books')
   

    def __str__(self):
        return self.title
    
