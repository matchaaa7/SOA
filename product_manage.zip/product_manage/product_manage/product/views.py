from rest_framework import viewsets
from rest_framework.decorators import action
from rest_framework.response import Response
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.filters import SearchFilter, OrderingFilter

from .models import Product
from .serializers import ProductSerializer


class ProductViewSet(viewsets.ModelViewSet):
    """
    CRUD + Filters + Search + Ordering + Custom actions
    """
    queryset = Product.objects.all()
    serializer_class = ProductSerializer

    # ฟิลเตอร์/ค้นหา/จัดเรียง
    filter_backends = [DjangoFilterBackend, SearchFilter, OrderingFilter]
    filterset_fields = ['category', 'is_active']      # /api/products/?category=...&is_active=true
    search_fields = ['name', 'category']              # /api/products/?search=shirt
    ordering_fields = ['name', 'price', 'stock', 'updated_at', 'created_at']
    ordering = ['-updated_at']                        # เรียงล่าสุดก่อนเป็นค่า default

    # /api/products/in_stock/
    @action(detail=False, methods=['get'])
    def in_stock(self, request):
        products = Product.objects.filter(stock__gt=0)
        return Response(self.get_serializer(products, many=True).data)

    # /api/products/{pk}/toggle_active/
    @action(detail=True, methods=['post'])
    def toggle_active(self, request, pk=None):
        product = self.get_object()
        product.is_active = not product.is_active
        product.save(update_fields=['is_active'])
        return Response({
            'id': product.id,
            'name': product.name,
            'is_active': product.is_active,
            'message': f'สถานะการขายของ "{product.name}" เปลี่ยนเป็น {product.is_active}.'
        })

    # /api/products/category/{category_name}/
    @action(detail=False, methods=['get'], url_path=r'category/(?P<category_name>[^/.]+)')
    def by_category(self, request, category_name=None):
        products = Product.objects.filter(category__iexact=category_name)
        return Response(self.get_serializer(products, many=True).data)
